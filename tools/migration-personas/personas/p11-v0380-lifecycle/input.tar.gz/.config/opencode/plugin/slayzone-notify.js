// SLAYZONE_COMPUTER_DISPATCHER=1
import { pathToFileURL } from 'node:url';
export const SlayzoneNotifyPlugin = async (context) => {
 const p = process.env.SLAYZONE_COMPUTER_HOOK_DIR ? process.env.SLAYZONE_COMPUTER_HOOK_DIR + '/opencode-plugin.mjs' : "/home/persona/.slayzone/hooks/opencode-default.mjs";
 return (await import(pathToFileURL(p).href)).SlayzoneNotifyPlugin(context);
};

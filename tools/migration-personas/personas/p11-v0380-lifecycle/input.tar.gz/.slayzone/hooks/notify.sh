#!/usr/bin/env bash
# SLAYZONE_NOTIFY_VERSION=2147483647
# SLAYZONE_COMPUTER_DISPATCHER=1
if [ -n "${SLAYZONE_COMPUTER_HOOK_DIR:-}" ]; then
  exec bash "$SLAYZONE_COMPUTER_HOOK_DIR/notify.sh" "$@"
fi
exec bash '/home/persona/.slayzone/hooks/notify-default.sh' "$@"

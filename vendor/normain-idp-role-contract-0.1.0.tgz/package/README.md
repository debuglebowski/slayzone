# @normain/idp-role-contract

Shared, runtime-neutral human IdP role policy. See [CONTRACT.md](CONTRACT.md) for API. No transport, JWT library, database, environment reader or logging dependency. Node >=20; Bun supported.

```js
import {parseConfig, resolveGrants, revalidateOidc} from '@normain/idp-role-contract';
import {runCommonFixtures, runAdapterAcceptance} from '@normain/idp-role-contract/fixtures';
const config = parseConfig(process.env, ['admin', 'user']);
await runCommonFixtures();
// Adapter's isolated native integration harness:
await runAdapterAcceptance({run: async scenario => nativeHarness(scenario)});
```

## Native acceptance setup

Each callback resets isolated state, configures mode on with known mapped targets unless scenario is mode_off, calls native authentication/authorization routes and inspects persisted storage and audit. Return actual observations; do not manufacture flags or call shared pure functions as native coverage. The runner cannot prove honesty of observations: reviewers must inspect the harness. Native role names/precedence remain service-specific.

| Scenario | Required setup and observations |
| --- | --- |
| mode_off | Existing local/password behavior unchanged; allowed and localBehaviorPreserved. |
| grant | Verified SSO role maps to native nonempty grants; allowed. |
| remove | Existing two managed grants, verified claim removes one; previousGrants and current nonempty grants show removal. For exclusive-role services use a downgrade. |
| deny | Verified unmapped claim removes all managed assignments; denied; human sessions/user credentials revoked; automation preserved. |
| invalid_claim | Verified malformed/missing role claim; same deny/removal/revocation observations. |
| password_refused | Managed password login denied; requiresSso. |
| local_change_refused | Managed role mutation via native route denied; statusCode 409, errorCode ROLES_MANAGED_BY_IDP, exact message. Also cover other UI/API/CLI entry points in native tests. |
| credentials_revoked | Existing human CLI/API credential plus session; lose last role; credential access denied, both revoked; automation preserved. |
| freshness_deadline | At verifiedAt+interval (max 3600), refreshed evidence missing or invalid; denied, requiresSso, verifiedAtUnchanged. Exercise each authenticated entry point. |
| activation | Persist mode/config epoch; invalidate pre-epoch human sessions/user credentials; restart is idempotent; off/on increments activation epoch; new verified session remains valid; automation preserved. Return activationPersisted, activationIdempotent, newlyVerifiedSessionValid. |
| audit | Observe native emitted stable event with required fields; no extra secret fields, sorted grants. Audit every decision/refusal in native tests. |

Standalone common command (after installing tarball):

```sh
node node_modules/@normain/idp-role-contract/dist/fixtures-cli.js
# Or bun node_modules/@normain/idp-role-contract/dist/fixtures-cli.js
```

## Security integration requirements

Only pass verified claim maps. OIDC verification callback verifies signature, allowed algorithm, issuer, audience, azp where applicable, expiry/not-before, and provider refresh semantics. Do not decode a JWT and call it verified. Shared flow requires own sub, own numeric integer iat, iat <= now, age < interval, and iat newer than persisted verification. Roles expire at signed iat+interval, so repeatedly returning an old token cannot extend authorization. Providers omitting current role evidence must use fresh SSO. No ID token in refresh response requires SSO even when access token refresh succeeded. `force:true` refreshes even if local evidence remains within interval; for login use newly verified authorization response directly and persist signed evidence time. SAML must verify fresh assertion, conditions/audience/recipient/InResponseTo and persist replay IDs; never emulate refresh tokens. A provider session may establish fresh assertion without another MFA challenge.

Gate every web/API/CLI human authenticated entry using persisted verifiedAt and config epoch. Persist auth verification across restart. Native grant reconciliation removes managed owner assignments too; local role definitions and personal overrides remain local. `resolveTargets` may only select a subset of mapped targets, never add grants. Missing/malformed entire claim array denies; exact own key precedes nested own path.

Persist activation epoch/config identity transactionally and idempotently. Enabling mode or changing managed config creates a new epoch; repeated startup does not. Persist off transition too, so off/on is a new activation. Revoke pre-epoch human sessions and user credentials. New SSO sessions bind to current epoch; never invalidate them through a delayed activation sweep. Automation credentials are excluded. Mode off preserves native behavior; startup validation still rejects malformed supplied config.

Serialize each identity's refresh operation with a database/distributed lock (cover transport and persistence). Inside the lock reread latest verification time/refresh token/epoch, then call shared orchestration. `persistVerified` must atomically reconcile roles and persist signed verification time + rotated token with expected identity revision and mode/config epoch. Preserve the existing refresh token only if response omits replacement; explicit null means clear. A lock is required where providers invalidate rotated tokens; a CAS alone detects conflicts but cannot prevent duplicate refresh requests. `requireSso` must atomically clear managed authorization, revoke human credentials and sessions, and fence the same expected revision/epoch. If a newer verification won, stale callbacks must fail closed for the stale request without revoking the newer session. Callback rejection propagates; adapters must deny that request. Never convert errors into allowed access or extend timestamps in finally blocks. Do not log callback exceptions or token responses in audit.

Real OIDC adapters must pass hooks.getNow returning current wall-clock Unix seconds. Shared flow reads it at entry and after remote verification, rejecting nonfinite or backward time. input.now is a deterministic test fallback. Evidence deadlines use completion time, with no clock-skew extension. Synchronize host clocks. Audit builder strips extra fields but does not redact secrets embedded in approved fields: use opaque IDs and static reason codes. Never supply raw token/claim dumps to audit fields.

## Migration and packaging

Use literal canonical IDP_* env names unless the approved service adapter namespace explicitly applies. Remove old names; no permissive fallback. Built-in rejection covers Kahuna SSO_ROLES_FROM_IDP, SSO_ROLE_CLAIM, SSO_ROLE_MAP, SSO_ROLE_UNMAPPED; Cloudable ROLES_FROM_IDP, IDP_ROLE_UNMAPPED; SlayZone SLAYZONE_HUB_SSO_ENABLE_ROLE_CLAIM, SLAYZONE_HUB_SSO_ROLE_CLAIM, SLAYZONE_HUB_SSO_ROLE_MAP, SLAYZONE_HUB_SSO_ROLE_UNMAPPED. Adapters may add keys with parseConfig's third argument `{legacyKeys:[...]}`. Reject supplied legacy keys even when false/empty. Configure explicit arrays and known native target names. Empty/all-empty managed mappings fail startup. No fallback role or automatic admin promotion. Recovery is server administration.

Copy release/normain-idp-role-contract-0.1.0.tgz to each service vendor directory, pin file dependency and regenerate lockfile. Verify SHA-256 against release/SHA256SUMS before installation. No sibling-directory dependency. `npm ci --ignore-scripts && npm run build && npm test && npm run pack:immutable` reproduces package. The pack script refuses to replace release bytes with a different digest. No external publishing. Package has explicit root + fixtures exports and zero runtime dependencies.

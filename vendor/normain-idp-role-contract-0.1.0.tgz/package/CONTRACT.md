# @normain/idp-role-contract 0.1.0

Stable implementation contract. Zero runtime dependencies, ESM built JS + TypeScript declarations; Node >=20 and Bun. All time values are Unix **seconds**. Only adapters verify signatures/issuer/audience/nonce/subject and persist changes; raw JWT decoding is never verification.

## Root exports

```ts
type RoleConfig = { enabled: boolean; claim: string; mapping: Readonly<Record<string, readonly string[]>>; intervalSec: number };
parseConfig(env: Readonly<Record<string,string|undefined>>, allowedTargets: readonly string[], options?: {legacyKeys?: readonly string[]}): RoleConfig;
extractClaim(claims: unknown, claim: string): string[];
mapRoles(values: readonly string[], mapping: RoleConfig['mapping']): string[];
resolveGrants(claims: unknown, config: RoleConfig): string[];
freshness(now: number, verifiedAt: number|null|undefined, intervalSec?: number): 'ok'|'require_sso';
```

`parseConfig` consumes canonical IDP_ROLES_ENABLED/IDP_ROLE_CLAIM/IDP_ROLE_MAPPING/IDP_RECHECK_INTERVAL_SECONDS; adapters normalize prefixes before calling. Off by default. Strict true|false, interval integer 1..3600, default 3600; managed mode requires nonempty claim and explicit object mapping with array targets (empty arrays allowed = deny, but empty/all-empty managed mappings rejected). Unknown targets rejected. Any supplied legacy ROLES_FROM_IDP* / IDP_ROLES_FROM_IDP* key or known old SSO/SlayZone key rejected (see README); options.legacyKeys adds service-specific names, even alongside new keys. Malformed supplied settings rejected even off. Throws `IdpRoleError` with code `INVALID_IDP_ROLE_CONFIG` and safe message. Exact own key wins before own-property dotted path; accepts nonempty string/string arrays only, otherwise empty. Case sensitive, deduplicated sorted grants, no implicit grants. Service precedence stays in adapters (Cloudable approver alone must deny).

```ts
const ROLES_MANAGED_BY_IDP = 'ROLES_MANAGED_BY_IDP';
const ROLES_MANAGED_MESSAGE = 'Roles are managed by your identity provider.';
const ROLES_MANAGED_HTTP_STATUS = 409;
class IdpRoleError extends Error { code: string }
type AuditEventName = 'idp_roles.granted'|'idp_roles.denied'|'idp_roles.revalidated'|'idp_roles.local_change_refused'|'idp_roles.activation';
type AuditEvent = { event: AuditEventName; service: string; actor: string; subject: string; source: 'oidc'|'saml'|'local'|'activation'; previousGrants: string[]; newGrants: string[]; reason: string };
buildAuditEvent(input: AuditEvent): AuditEvent;
```

Audit builder allowlists fields, copies and sorts grants; callers use opaque actor/subject IDs and safe static reason codes, never secrets/tokens. Every role decision/refusal must be logged by adapter.

## Shared OIDC orchestration

```ts
type RevalidationReason = 'mode_off'|'fresh'|'verified'|'refresh_unavailable'|'refresh_failed'|'missing_id_token'|'verification_failed'|'subject_mismatch'|'no_mapped_role'|'persistence_failed'|'invalid_time'|'stale_evidence';
type OidcResult = {status:'ok'; reason:RevalidationReason; grants:string[]; verifiedAt:number|null} | {status:'require_sso'; reason:RevalidationReason; grants:[]; verifiedAt:null};
type OidcInput = {
 config:RoleConfig; now:number; verifiedAt?:number|null; subject:string;
 currentGrants:readonly string[]; refreshToken?:string|null; force?:boolean;
 hooks:{
  getNow?:()=>number;
  refresh?:(refreshToken:string)=>Promise<{idToken?:string|null;refreshToken?:string|null}>;
  verifyIdToken:(idToken:string)=>Promise<Record<string,unknown>>;
  persistVerified:(state:{subject:string;grants:string[];verifiedAt:number;refreshToken?:string|null})=>Promise<void>;
  requireSso:(state:{subject:string;reason:RevalidationReason;grants:[]})=>Promise<void>;
  resolveTargets?:(mapped:string[])=>string[];
 }
};
revalidateOidc(input:OidcInput):Promise<OidcResult>;
```

One implementation used by Kahuna + SlayZone. Real adapters pass hooks.getNow returning wall-clock Unix seconds. Clock is read before freshness gating and again after remote verification; invalid/backward completion time denies. input.now is deterministic fallback only. Role evidence age is checked against completion time without skew extension. Call at every authenticated entry point; `force:true` at login (or reconcile newly verified login claims via resolveGrants). Refresh is called only when due/forced. A newly returned nonempty ID token is mandatory. `verifyIdToken` must establish fresh role evidence bound to same issuer/client/subject; enforce provider token time/replay rules. No access-token-only response, cached claims, or old token fallback. Own `sub` must equal input subject. Own signed `iat` is required: integer Unix seconds, nonfuture, age strictly less than interval, newer than prior verification. Persisted verifiedAt is signed iat, never receipt time; old evidence cannot extend deadline. Missing/invalid claims or no effective targets => deny. `resolveTargets` optional service precedence callback, may only remove mapped targets. Serialize identity refresh and reread state under a distributed/storage lock before invoking; persist verified roles/time/rotated refresh token atomically with expected revision/epoch. Invalidation must fence that revision too, preserving newer SSO sessions; see README. On failure invoke requireSso to persist invalidation of sessions and user credentials; callback failures fail closed (throws), never return ok. Disable mode returns current grants without hooks. Freshness requires finite nonfuture verifiedAt and elapsed strictly less than interval; deadline inclusive requires recheck. Adapter stores verification time per human identity, handles SAML replay + verified assertions, persisted config activation epoch/idempotent invalidation, session epochs, audit and local/password mutation guards. No automation credential revocation.

## Acceptance entry points

`@normain/idp-role-contract/fixtures` exports `runCommonFixtures(): Promise<{passed:number}>` (throws on failure), and `runAdapterAcceptance(adapter): Promise<{passed:number}>`. The latter consumes `AdapterAcceptance` interface published in declarations: isolated scenario callback `run(scenario: AcceptanceScenario): Promise<AcceptanceObservation>`, with exported `acceptanceScenarios`. Each adapter runs its native harness, observing off-mode, grant/remove/deny, invalid claim, password/local refusal, revocation, deadline, activation and audit. No live users. Both entry points run on Node/Bun without a test-framework dependency. CLI `node node_modules/@normain/idp-role-contract/dist/fixtures-cli.js` runs common fixtures.

## Packaging

Install identical immutable `release/normain-idp-role-contract-0.1.0.tgz`, copy to each service's vendor directory then pin `file:vendor/normain-idp-role-contract-0.1.0.tgz` + lockfile. Never sibling-directory dependencies. SHA-256 in release/SHA256SUMS. `npm ci && npm run build && npm test && npm run pack:immutable` reproduces tarball; no external publication. Root export `.` and `/fixtures` only. Artifact includes dist JS/declarations, CONTRACT.md, README.md and package.json. Release bytes frozen after adapters notified.
